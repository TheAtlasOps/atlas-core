"""
ATLAS FSM QA v2 — Suite de Pruebas Unitarias y de Lógica de Negocio
Casos cubiertos: 20 casos de prueba unitarios (TC-M01, TC-M02, TC-M03, TC-M04, TC-M05, TC-M06, TC-M07, TC-M08)
Ejecutable mediante: pytest qa/tests/unit/test_unit_suite.py -v
"""

import math
import re
import uuid
from datetime import datetime, timedelta, timezone
import pytest
from pydantic import ValidationError

from app.core.security import (
    get_password_hash,
    verify_password,
    create_access_token,
    decode_access_token,
    generate_magic_link_token,
)
from app.models.enums import (
    UserRoleEnum,
    OrderStatusEnum,
    OrderPriorityEnum,
    ServiceTypeEnum,
    EquipmentTypeEnum,
    EquipmentStatusEnum,
    SimStatusEnum,
)
from app.schemas.client import ClientBase, ClientCreate
from app.schemas.inventory import EquipmentBase, SimCardBase
from app.schemas.work_order import WorkOrderBase, WorkOrderCreate, WorkOrderStatusUpdate


# ==============================================================================
# M01: AUTENTICACIÓN, SESIONES Y CRIPTOGRAFÍA
# ==============================================================================

def test_tc_m01_01_unit_password_hashing():
    """TC-M01-01: Verificación de hash unidireccional bcrypt y rechazo de passwords incorrectas."""
    plain = "AtlasSecure2026!#"
    hashed = get_password_hash(plain)

    assert hashed != plain
    assert hashed.startswith("$2b$") or hashed.startswith("$2a$")
    assert verify_password(plain, hashed) is True
    assert verify_password("WrongPassword123!", hashed) is False


def test_tc_m01_02_unit_password_length_policy():
    """TC-M01-02: Política de contraseña (mínimo 12 caracteres y límite seguro bcrypt 72 bytes)."""
    short_pass = "Short123!"
    assert len(short_pass) < 12  # Incumple política

    valid_pass = "AtlasSuperSecret2026!"
    assert len(valid_pass) >= 12
    assert len(valid_pass.encode("utf-8")) <= 72

    # Límite de 72 bytes de bcrypt
    oversized_pass = "A" * 73
    assert len(oversized_pass.encode("utf-8")) > 72


def test_tc_m01_03_unit_jwt_token_claims_and_expiration():
    """TC-M01-03: Emisión de token JWT con algoritmo HS256, claims sub, role y expiración."""
    user_id = str(uuid.uuid4())
    role = UserRoleEnum.COORDINADOR.value
    delta = timedelta(minutes=45)

    token = create_access_token(subject=user_id, role=role, expires_delta=delta)
    assert isinstance(token, str)
    assert len(token.split(".")) == 3  # Formato estándar header.payload.signature

    payload = decode_access_token(token)
    assert payload is not None
    assert payload["sub"] == user_id
    assert payload["role"] == role
    assert "exp" in payload
    assert payload["exp"] > datetime.now(timezone.utc).timestamp()


# ==============================================================================
# M02: ÓRDENES DE TRABAJO Y MÁQUINA DE ESTADOS
# ==============================================================================

def test_tc_m02_01_unit_valid_order_state_transitions():
    """TC-M02-01: Validación de transiciones permitidas en la máquina de estados de órdenes."""
    # Transición progresiva legal: IDLE/CONFIRMADA -> EN_RUTA -> EN_SITIO -> COMPLETADA
    allowed_transitions = {
        OrderStatusEnum.IDLE: [OrderStatusEnum.CONFIRMADA, OrderStatusEnum.CANCELADA],
        OrderStatusEnum.CONFIRMADA: [OrderStatusEnum.EN_RUTA, OrderStatusEnum.CANCELADA],
        OrderStatusEnum.EN_RUTA: [OrderStatusEnum.EN_SITIO, OrderStatusEnum.CANCELADA],
        OrderStatusEnum.EN_SITIO: [OrderStatusEnum.COMPLETADA, OrderStatusEnum.CANCELADA],
        OrderStatusEnum.COMPLETADA: [],  # Estado terminal
        OrderStatusEnum.CANCELADA: [],   # Estado terminal
    }

    current = OrderStatusEnum.CONFIRMADA
    next_step = OrderStatusEnum.EN_RUTA
    assert next_step in allowed_transitions[current]

    update_schema = WorkOrderStatusUpdate(new_status=OrderStatusEnum.EN_RUTA)
    assert update_schema.new_status == OrderStatusEnum.EN_RUTA


def test_tc_m02_02_unit_reject_invalid_backward_state_transition():
    """TC-M02-02: Bloqueo de transiciones ilegales retroactivas desde estados terminales."""
    terminal_state = OrderStatusEnum.COMPLETADA
    illegal_target = OrderStatusEnum.EN_RUTA

    # Definición de regla de negocio: no se puede reactivar una orden completada
    can_reopen = (terminal_state != OrderStatusEnum.COMPLETADA and terminal_state != OrderStatusEnum.CANCELADA)
    assert can_reopen is False


# ==============================================================================
# M03: GESTIÓN DE CLIENTES Y VALIDACIÓN DE CONTACTO
# ==============================================================================

def test_tc_m03_01_unit_client_email_schema_validation():
    """TC-M03-01: Validación Pydantic de formato de correo corporativo para clientes."""
    valid_data = {
        "business_name": "Entel PCS Telecomunicaciones S.A.",
        "contact_email": "soporte.empresas@entel.cl",
        "contact_phone": "+56912345678",
        "address": "Av. Andrés Bello 2711, Las Condes",
    }
    client = ClientBase(**valid_data)
    assert client.contact_email == "soporte.empresas@entel.cl"

    # Correo inválido debe arrojar ValidationError
    invalid_data = valid_data.copy()
    invalid_data["contact_email"] = "correo-invalido-sin-arroba"
    with pytest.raises(ValidationError):
        ClientBase(**invalid_data)


def test_tc_m03_02_unit_client_phone_and_address_normalization():
    """TC-M03-02: Validación de teléfono chileno y dirección mínima requerida."""
    valid_client = ClientCreate(
        business_name="Logística Maipo SpA",
        contact_email="contacto@maipo.cl",
        contact_phone="+56 9 8765 4321",
        address="Camino a Melipilla 1234",
        comuna="Maipú",
    )
    assert len(valid_client.contact_phone) >= 5
    assert valid_client.comuna == "Maipú"


# ==============================================================================
# M04: PORTAL CLIENTE Y MAGIC LINKS CRIPTOGRÁFICOS
# ==============================================================================

def test_tc_m04_01_unit_magic_link_token_entropy():
    """TC-M04-01: Generación de token criptográfico de alta entropía con secrets.token_urlsafe."""
    token1 = generate_magic_link_token()
    token2 = generate_magic_link_token()

    assert len(token1) >= 42  # 32 bytes base64url ~ 43 chars
    assert len(token2) >= 42
    assert token1 != token2
    assert re.match(r"^[A-Za-z0-9_-]+$", token1)


def test_tc_m04_02_unit_magic_link_expiration_window():
    """TC-M04-02: Verificación de cálculo de vigencia temporal de Magic Links."""
    now = datetime.now(timezone.utc)
    expire_hours = 48
    expires_at = now + timedelta(hours=expire_hours)

    is_valid_initially = now < expires_at
    assert is_valid_initially is True

    # Simular tiempo futuro expirado
    future_expired = now + timedelta(hours=49)
    assert future_expired > expires_at


# ==============================================================================
# M05: INVENTARIO DE HARDWARE Y SIMS
# ==============================================================================

def test_tc_m05_01_unit_router_mac_and_serial_validation():
    """TC-M05-01: Validación de formato de dirección MAC física y número de serie de router."""
    valid_equipment = EquipmentBase(
        serial_number="RUT240-TEST-9999",
        mac_address="00:1A:2B:3C:4D:5E",
        brand="Teltonika",
        model="RUT240",
        type=EquipmentTypeEnum.ROUTER_4G,
    )
    assert valid_equipment.mac_address == "00:1A:2B:3C:4D:5E"

    # MAC inválida debe lanzar ValidationError
    with pytest.raises(ValidationError):
        EquipmentBase(
            serial_number="RUT240-BAD",
            mac_address="INVALID-MAC-ADDRESS",
            brand="Teltonika",
            model="RUT240",
            type=EquipmentTypeEnum.ROUTER_4G,
        )


def test_tc_m05_02_unit_sim_card_iccid_format():
    """TC-M05-02: Validación de formato de ICCID en tarjetas SIM (19 a 22 dígitos)."""
    valid_sim = SimCardBase(
        iccid="8956012345678901234F",
        imsi="730011234567890",
        operator="Entel",
    )
    assert valid_sim.iccid.startswith("8956")
    assert valid_sim.operator == "Entel"


# ==============================================================================
# M06: NOTIFICACIONES OPERATIVAS
# ==============================================================================

def test_tc_m06_01_unit_notification_event_creation():
    """TC-M06-01: Generación de evento estructurado de notificación ante cambio de estado de OT."""
    order_id = uuid.uuid4()
    event_payload = {
        "event_type": "ORDER_STATUS_CHANGED",
        "order_id": str(order_id),
        "old_status": OrderStatusEnum.CONFIRMADA.value,
        "new_status": OrderStatusEnum.EN_RUTA.value,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "message": f"La orden {order_id} ha cambiado de estado a EN RUTA.",
    }

    assert event_payload["new_status"] == "EN_RUTA"
    assert "ORDER_STATUS_CHANGED" in event_payload["event_type"]


# ==============================================================================
# M07: DESPACHO, GEORREFERENCIACIÓN Y RUTAS
# ==============================================================================

def calculate_haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calcula la distancia geodésica entre dos puntos en kilómetros."""
    R = 6371.0  # Radio medio de la Tierra en km
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2) ** 2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


def test_tc_m07_01_unit_haversine_distance_santiago():
    """TC-M07-01: Cálculo de distancia geodésica Haversine entre técnico (Providencia) y cliente (Las Condes)."""
    # Técnico: Providencia (-33.4255, -70.6120)
    tech_lat, tech_lon = -33.4255, -70.6120
    # Cliente: Las Condes (-33.4110, -70.5750)
    client_lat, client_lon = -33.4110, -70.5750

    dist_km = calculate_haversine_distance(tech_lat, tech_lon, client_lat, client_lon)
    assert 3.5 <= dist_km <= 4.5  # Distancia estimada ~3.8 km


def test_tc_m07_02_unit_eta_calculation():
    """TC-M07-02: Estimación de tiempo de arribo (ETA) según distancia y velocidad urbana promedio."""
    dist_km = 4.0
    avg_speed_kmh = 30.0  # 30 km/h en ciudad
    travel_time_hours = dist_km / avg_speed_kmh
    travel_time_minutes = travel_time_hours * 60

    assert 7.0 <= travel_time_minutes <= 9.0  # ~8 minutos


def test_tc_m07_03_unit_coordinate_bounding_box_rm():
    """TC-M07-03: Validación de coordenadas geográficas dentro del radio de la Región Metropolitana."""
    # Bounding box aproximado Región Metropolitana: lat [-34.2, -33.0], lon [-71.5, -70.0]
    def is_in_santiago_rm(lat: float, lon: float) -> bool:
        return -34.2 <= lat <= -33.0 and -71.5 <= lon <= -70.0

    santiago_center = (-33.4489, -70.6693)
    assert is_in_santiago_rm(*santiago_center) is True

    punta_arenas = (-53.1638, -70.9171)
    assert is_in_santiago_rm(*punta_arenas) is False


def test_tc_m07_04_unit_route_interpolation_progress():
    """TC-M07-04: Simulación de avance de camioneta: interpolación lineal de coordenadas."""
    start = (-33.4400, -70.6500)
    end = (-33.4200, -70.6100)
    fraction = 0.5  # 50% del recorrido

    interpolated_lat = start[0] + (end[0] - start[0]) * fraction
    interpolated_lon = start[1] + (end[1] - start[1]) * fraction

    assert round(interpolated_lat, 4) == -33.4300
    assert round(interpolated_lon, 4) == -70.6300


# ==============================================================================
# M08: CONTROL DE ACCESO RBAC Y SEGURIDAD
# ==============================================================================

def test_tc_m08_02_unit_sql_injection_sanitization_regex():
    """TC-M08-02: Verificación de patrones de detección de inyección SQL en parámetros de búsqueda."""
    suspicious_payloads = [
        "' OR '1'='1",
        "'; DROP TABLE work_orders; --",
        "admin' --",
        "1 UNION SELECT null, username, password FROM users",
    ]
    sqli_pattern = re.compile(r"('|--|;|\bUNION\b|\bSELECT\b|\bDROP\b)", re.IGNORECASE)

    for payload in suspicious_payloads:
        assert bool(sqli_pattern.search(payload)) is True

    clean_search = "Teltonika RUT240 Las Condes"
    # No contiene comandos SQL destructivos directos
    assert ("DROP" not in clean_search and "UNION" not in clean_search)


def test_tc_m08_03_unit_cors_origin_regex_validation():
    """TC-M08-03: Validación de expresión regular CORS para dominios Vercel autorizados."""
    cors_regex = re.compile(r"https://.*\.vercel\.app")

    assert bool(cors_regex.match("https://atlas-fsm.vercel.app")) is True
    assert bool(cors_regex.match("https://preview-123.vercel.app")) is True
    assert bool(cors_regex.match("http://insecure-site.com")) is False


def test_tc_m06_04_unit_notification_template_html():
    """TC-M06-04: Generación y renderizado de plantilla HTML de notificación con identidad ATLAS/Entel."""
    from app.services.email_service import build_magic_link_html
    html = build_magic_link_html(
        client_name="Entel Empresas Chile S.A.",
        order_number="OT-2026-QA01",
        service_type="INSTALACION_FIBRA",
        scheduled_date_str="15/11/2026 10:00",
        address="Av. Costanera Sur 2730, Las Condes",
        magic_link_url="https://atlasfsm.cl/client/token-seguro-qa",
        technician_name="Técnico Terreno QA",
    )
    assert "Entel Empresas Chile S.A." in html
    assert "OT-2026-QA01" in html
    assert "https://atlasfsm.cl/client/token-seguro-qa" in html
    assert "ENTEL FSM" in html or "Atlas" in html


def test_tc_m05_03_unit_equipment_type_classification():
    """TC-M05-03-UNIT: Clasificación de tipos de equipamiento soportados por la plataforma."""
    types = [e.value for e in EquipmentTypeEnum]
    assert "ROUTER_4G" in types
    assert "ROUTER_5G" in types
    assert "ANTENA_EXTERNA" in types
    assert len(types) >= 5
