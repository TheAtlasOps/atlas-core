"""
ATLAS FSM QA v2 — Suite de Pruebas de Integración de API (FastAPI In-Memory ASGI)
Casos cubiertos: Exactamente 28 casos de prueba API (TC-M01, TC-M02, TC-M03, TC-M04, TC-M05, TC-M06, TC-M08)
Ejecución: pytest qa/tests/api/test_api_suite.py -v -p no:cacheprovider
"""

import json
import uuid
from datetime import datetime, timezone
from decimal import Decimal
from unittest.mock import AsyncMock, MagicMock, patch
from urllib.parse import urlparse

import pytest

from app.main import app
from app.core.database import get_db
from app.api.deps import get_current_active_user, get_current_user
from app.models.enums import UserRoleEnum, OrderStatusEnum, OrderPriorityEnum, ServiceTypeEnum
from app.models.user import User
from app.models.work_order import WorkOrder
from app.models.client import Client
from app.schemas.client import ClientResponse
from qa.fixtures.data import (
    MOCK_USERS,
    MOCK_CLIENTS,
    MOCK_ORDERS,
    MOCK_INVENTORY,
    MOCK_MAGIC_LINKS,
)


# ---------------------------------------------------------------------------
# ASGI Test Runner In-Memory (Zero Socket / Zero Network / Offline Deterministic)
# ---------------------------------------------------------------------------

def run_async(coro):
    """Ejecutor directo de corrutinas en espacio de memoria puro sin sockets."""
    stack = [coro]
    result = None
    while stack:
        current = stack[-1]
        try:
            val = current.send(result)
            if hasattr(val, "send"):
                stack.append(val)
                result = None
            else:
                result = val
        except StopIteration as exc:
            stack.pop()
            result = exc.value
    return result


class ASGIResponse:
    """Representación de la respuesta HTTP devuelta por el servidor ASGI."""
    def __init__(self, status_code: int, headers: dict, body: bytes):
        self.status_code = status_code
        self.headers = headers
        self._body = body

    @property
    def content(self) -> bytes:
        return self._body

    @property
    def text(self) -> str:
        return self._body.decode("utf-8")

    def json(self):
        if not self._body:
            return None
        return json.loads(self.text)


class InMemoryClient:
    """Cliente HTTP de pruebas que invoca la aplicación FastAPI directamente por ASGI."""
    def __init__(self, asgi_app):
        self.app = asgi_app

    def request(self, method: str, url: str, json_data=None, headers=None) -> ASGIResponse:
        parsed = urlparse(url)
        path = parsed.path
        raw_qs = parsed.query.encode("ascii")

        hdrs = [(b"host", b"testserver")]
        body_bytes = b""
        if json_data is not None:
            body_bytes = json.dumps(json_data).encode("utf-8")
            hdrs.append((b"content-type", b"application/json"))
            hdrs.append((b"content-length", str(len(body_bytes)).encode("ascii")))
        if headers:
            for k, v in headers.items():
                hdrs.append((k.lower().encode("ascii"), v.encode("ascii")))

        scope = {
            "type": "http",
            "asgi": {"version": "3.0"},
            "http_version": "1.1",
            "method": method.upper(),
            "path": path,
            "raw_path": path.encode("ascii"),
            "query_string": raw_qs,
            "headers": hdrs,
            "client": ("127.0.0.1", 12345),
            "server": ("testserver", 80),
            "scheme": "http",
        }

        res_status = None
        res_headers = {}
        res_body = bytearray()

        async def receive():
            return {"type": "http.request", "body": body_bytes, "more_body": False}

        async def send(msg):
            nonlocal res_status, res_headers, res_body
            if msg["type"] == "http.response.start":
                res_status = msg["status"]
                res_headers = {k.decode("latin1"): v.decode("latin1") for k, v in msg.get("headers", [])}
            elif msg["type"] == "http.response.body":
                res_body.extend(msg.get("body", b""))

        run_async(self.app(scope, receive, send))
        return ASGIResponse(res_status, res_headers, bytes(res_body))

    def get(self, url: str, headers=None) -> ASGIResponse:
        return self.request("GET", url, headers=headers)

    def post(self, url: str, json=None, headers=None) -> ASGIResponse:
        return self.request("POST", url, json_data=json, headers=headers)

    def put(self, url: str, json=None, headers=None) -> ASGIResponse:
        return self.request("PUT", url, json_data=json, headers=headers)

    def patch(self, url: str, json=None, headers=None) -> ASGIResponse:
        return self.request("PATCH", url, json_data=json, headers=headers)

    def delete(self, url: str, headers=None) -> ASGIResponse:
        return self.request("DELETE", url, headers=headers)


# ---------------------------------------------------------------------------
# Fixtures de Pytest
# ---------------------------------------------------------------------------

@pytest.fixture
def client():
    """Instancia del cliente ASGI in-memory."""
    return InMemoryClient(app)


@pytest.fixture
def mock_db():
    """Sesión de base de datos simulada y aislada."""
    session = AsyncMock()
    mock_res = MagicMock()
    mock_res.scalars.return_value.all.return_value = []
    mock_res.scalar_one_or_none.return_value = None
    session.execute.return_value = mock_res
    session.commit.return_value = None
    session.rollback.return_value = None
    session.refresh.return_value = None

    async def _get_db_override():
        yield session

    app.dependency_overrides[get_db] = _get_db_override
    yield session
    app.dependency_overrides.pop(get_db, None)


@pytest.fixture
def coordinator_user():
    return User(
        id=uuid.UUID(MOCK_USERS["coordinator"]["id"]),
        email=MOCK_USERS["coordinator"]["email"],
        full_name="Coordinador Operaciones",
        role=UserRoleEnum.COORDINADOR,
        is_active=True,
        auth_version=0,
    )


@pytest.fixture
def technician_user():
    return User(
        id=uuid.UUID(MOCK_USERS["technician"]["id"]),
        email=MOCK_USERS["technician"]["email"],
        full_name="Técnico Terreno",
        role=UserRoleEnum.TECNICO,
        is_active=True,
        auth_version=0,
    )


@pytest.fixture
def auth_coordinator(coordinator_user, mock_db):
    """Inyecta un usuario autenticado con rol COORDINADOR."""
    async def _get_coordinator():
        return coordinator_user

    app.dependency_overrides[get_current_active_user] = _get_coordinator
    app.dependency_overrides[get_current_user] = _get_coordinator
    yield coordinator_user
    app.dependency_overrides.pop(get_current_active_user, None)
    app.dependency_overrides.pop(get_current_user, None)


@pytest.fixture
def auth_technician(technician_user, mock_db):
    """Inyecta un usuario autenticado con rol TECNICO."""
    async def _get_technician():
        return technician_user

    app.dependency_overrides[get_current_active_user] = _get_technician
    app.dependency_overrides[get_current_user] = _get_technician
    yield technician_user
    app.dependency_overrides.pop(get_current_active_user, None)
    app.dependency_overrides.pop(get_current_user, None)


# ==============================================================================
# M01: AUTENTICACIÓN Y SEGURIDAD API (5 casos)
# ==============================================================================

def test_tc_m01_04_api_login_invalid_credentials(client, mock_db):
    """TC-M01-04: Rechazo de autenticación con credenciales inválidas (HTTP 401)."""
    mock_res = MagicMock()
    mock_res.scalar_one_or_none.return_value = None
    mock_db.execute.return_value = mock_res

    res = client.post("/api/v1/auth/login", json={"email": "usuario.inexistente@atlasfsm.cl", "password": "WrongPassword99!"})
    assert res.status_code == 401
    assert "detail" in res.json()


def test_tc_m01_05_api_login_inactive_user_rejection(client, mock_db):
    """TC-M01-05: Rechazo de autenticación para cuenta deshabilitada (HTTP 401/403)."""
    res = client.post("/api/v1/auth/login", json={"email": "inactivo.qa@atlasfsm.cl", "password": "AnyPassword123!"})
    assert res.status_code in [401, 403]


def test_tc_m01_06_api_me_no_auth_header(client, mock_db):
    """TC-M01-06: Endpoint /auth/me rechaza peticiones sin cabecera Authorization (HTTP 401)."""
    res = client.get("/api/v1/auth/me")
    assert res.status_code == 401
    assert "not authenticated" in res.json().get("detail", "").lower()


def test_tc_m01_07_api_me_corrupt_jwt(client, mock_db):
    """TC-M01-07: Endpoint /auth/me rechaza token con firma alterada (HTTP 401)."""
    corrupt_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0In0.invalidsignature"
    res = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {corrupt_token}"})
    assert res.status_code == 401


def test_tc_m01_08_api_password_reset_request_neutral(client, mock_db):
    """TC-M01-08: Solicitud de restablecimiento responde HTTP 202 sin revelar existencia del correo."""
    with patch("app.api.v1.auth.request_password_reset", new_callable=AsyncMock):
        res = client.post("/api/v1/auth/password-reset/request", json={"email": "auditoria.qa@atlasfsm.cl"})
        assert res.status_code == 202
        assert "message" in res.json()


# ==============================================================================
# M02: ÓRDENES DE TRABAJO (API) (6 casos)
# ==============================================================================

def test_tc_m02_03_api_orders_list_requires_auth(client, mock_db):
    """TC-M02-03: Endpoint de órdenes exige autenticación JWT previa (HTTP 401)."""
    res = client.get("/api/v1/orders")
    assert res.status_code == 401


def test_tc_m02_04_api_orders_list_with_auth(client, auth_coordinator, mock_db):
    """TC-M02-04: Consulta de órdenes de trabajo con rol COORDINADOR autorizado (HTTP 200)."""
    with patch("app.api.v1.orders.list_orders", new_callable=AsyncMock) as mock_list:
        mock_list.return_value = ([], 0)
        res = client.get("/api/v1/orders")
        assert res.status_code == 200
        data = res.json()
        assert "items" in data
        assert data["total"] == 0


def test_tc_m02_05_api_orders_filter_priority(client, auth_coordinator, mock_db):
    """TC-M02-05: Filtrado de órdenes por parámetro priority=ALTA (HTTP 200)."""
    with patch("app.api.v1.orders.list_orders", new_callable=AsyncMock) as mock_list:
        mock_list.return_value = ([], 0)
        res = client.get("/api/v1/orders?priority=ALTA")
        assert res.status_code == 200
        assert "items" in res.json()


def test_tc_m02_06_api_orders_create_schema_validation_missing_type(client, auth_coordinator, mock_db):
    """TC-M02-06: Rechazo de creación de orden ante payload incompleto (HTTP 422)."""
    incomplete_payload = {
        "title": "Orden Incompleta Sin Tipo de Servicio",
        "priority": "ALTA",
    }
    res = client.post("/api/v1/orders", json=incomplete_payload)
    assert res.status_code == 422


def test_tc_m02_07_api_orders_create_valid_schema(client, auth_coordinator, mock_db):
    """TC-M02-07: Creación de orden de trabajo con payload completo y válido (HTTP 200/201)."""
    mock_order = WorkOrder(
        id=uuid.uuid4(),
        order_number="OT-2026-QA01",
        title="Instalación de Router Teltonika RUT240",
        service_type=ServiceTypeEnum.INSTALACION_FIBRA,
        priority=OrderPriorityEnum.ALTA,
        status=OrderStatusEnum.IDLE,
        client_id=uuid.uuid4(),
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
        client=None,
        technician=None,
        magic_links=[],
        evidences=[],
        status_history=[],
        items=[],
    )
    with patch("app.api.v1.orders.create_order", new_callable=AsyncMock) as mock_create:
        mock_create.return_value = mock_order
        valid_payload = {
            "title": "Instalación de Router Teltonika RUT240",
            "service_type": "INSTALACION_FIBRA",
            "priority": "ALTA",
            "description": "Instalación de conectividad M2M para backup de caja",
        }
        res = client.post("/api/v1/orders", json=valid_payload)
        assert res.status_code in [200, 201]


def test_tc_m02_08_api_orders_get_nonexistent_uuid(client, auth_coordinator, mock_db):
    """TC-M02-08: Consulta de orden con UUID inexistente retorna HTTP 404 Not Found."""
    fake_uuid = str(uuid.uuid4())
    res = client.get(f"/api/v1/orders/{fake_uuid}")
    assert res.status_code == 404


# ==============================================================================
# M03: GESTIÓN DE CLIENTES (API) (5 casos)
# ==============================================================================

def test_tc_m03_03_api_clients_list_requires_auth(client, mock_db):
    """TC-M03-03: Endpoint de clientes protegido ante acceso anónimo (HTTP 401)."""
    res = client.get("/api/v1/clients")
    assert res.status_code == 401


def test_tc_m03_04_api_clients_list_authenticated(client, auth_coordinator, mock_db):
    """TC-M03-04: Consulta de listado de clientes registrados con token de coordinador."""
    with patch("app.api.v1.clients.service_list_clients", new_callable=AsyncMock) as mock_list:
        mock_list.return_value = []
        res = client.get("/api/v1/clients")
        assert res.status_code == 200
        assert isinstance(res.json(), list)


def test_tc_m03_05_api_clients_create_invalid_email(client, auth_coordinator, mock_db):
    """TC-M03-05: Validación Pydantic rechaza registro de cliente con correo inválido (HTTP 422)."""
    bad_client = {
        "business_name": "Empresa Test SpA",
        "contact_email": "correo-no-valido",
        "contact_phone": "+56911223344",
        "address": "Calle Falsa 123",
        "comuna": "Santiago",
    }
    res = client.post("/api/v1/clients", json=bad_client)
    assert res.status_code == 422


def test_tc_m03_06_api_clients_create_valid_schema(client, auth_coordinator, mock_db):
    """TC-M03-06: Estructura de payload válido para creación de nuevo cliente (HTTP 201)."""
    mock_client_response = ClientResponse(
        id=uuid.uuid4(),
        business_name="Telecomunicaciones del Sur Ltda.",
        contact_person="Operaciones",
        contact_email="operaciones@telsur-test.cl",
        contact_phone="+56912345678",
        address="Av. Alemania 850, Temuco",
        comuna="Temuco",
        rut="77.654.321-0",
        active_orders_count=0,
        total_orders_count=0,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    with patch("app.api.v1.clients.service_create_client", new_callable=AsyncMock) as mock_create:
        mock_create.return_value = mock_client_response
        good_client = {
            "business_name": "Telecomunicaciones del Sur Ltda.",
            "contact_email": "operaciones@telsur-test.cl",
            "contact_phone": "+56912345678",
            "address": "Av. Alemania 850, Temuco",
            "comuna": "Temuco",
            "rut": "77.654.321-0",
        }
        res = client.post("/api/v1/clients", json=good_client)
        assert res.status_code in [200, 201]


def test_tc_m03_07_api_clients_get_by_id(client, auth_coordinator, mock_db):
    """TC-M03-07: Consulta de cliente por ID inexistente responde 404 Not Found."""
    test_id = str(uuid.uuid4())
    res = client.get(f"/api/v1/clients/{test_id}")
    assert res.status_code == 404


# ==============================================================================
# M04: PORTAL CLIENTE Y MAGIC LINKS (API) (4 casos)
# ==============================================================================

def test_tc_m04_03_api_portal_order_summary_invalid_token(client, mock_db):
    """TC-M04-03: Endpoint público rechaza Magic Link inválido o inexistente con HTTP 404."""
    res = client.get("/api/v1/client/order-summary?token=token-qa-completamente-invalido")
    assert res.status_code == 404


def test_tc_m04_04_api_portal_order_summary_missing_token_param(client, mock_db):
    """TC-M04-04: Solicitud sin parámetro de query 'token' es rechazada con HTTP 422."""
    res = client.get("/api/v1/client/order-summary")
    assert res.status_code == 422


def test_tc_m04_05_api_portal_confirm_visit_validation(client, mock_db):
    """TC-M04-05: Validación de payload para confirmación de visita del cliente."""
    confirm_payload = {
        "confirmed_by_name": "Juan Pérez",
        "contact_phone": "+56912345678",
    }
    res = client.post("/api/v1/client/confirm-visit?token=token-invalido-test", json=confirm_payload)
    assert res.status_code in [404, 422]


def test_tc_m04_06_api_portal_sign_conformity_validation(client, mock_db):
    """TC-M04-06: Endpoint de firma digital valida requerimiento de token y trazo."""
    res = client.post(
        "/api/v1/client/sign?token=token-invalido-test",
        json={"signature_data": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA..."},
    )
    assert res.status_code in [404, 422]


# ==============================================================================
# M05: INVENTARIO DE HARDWARE Y SIMS (API) (4 casos)
# ==============================================================================

def test_tc_m05_04_api_inventory_sims_list_requires_auth(client, mock_db):
    """TC-M05-04: Inventario de tarjetas SIM requiere autenticación (HTTP 401)."""
    res = client.get("/api/v1/inventory/sims")
    assert res.status_code == 401


def test_tc_m05_05_api_inventory_sims_list_authenticated(client, auth_coordinator, mock_db):
    """TC-M05-05: Consulta de inventario SIM con token de coordinación (HTTP 200)."""
    with patch("app.api.v1.inventory.list_sim_cards", new_callable=AsyncMock) as mock_list:
        mock_list.return_value = ([], 0)
        res = client.get("/api/v1/inventory/sims")
        assert res.status_code == 200
        assert "items" in res.json()


def test_tc_m05_06_api_inventory_routers_list(client, auth_coordinator, mock_db):
    """TC-M05-06: Consulta de inventario de Routers con soporte de paginación."""
    with patch("app.api.v1.inventory.list_equipment", new_callable=AsyncMock) as mock_list:
        mock_list.return_value = ([], 0)
        res = client.get("/api/v1/inventory/routers")
        assert res.status_code == 200
        assert "items" in res.json()


def test_tc_m05_07_api_inventory_routers_filter_type(client, auth_coordinator, mock_db):
    """TC-M05-07: Filtrado de routers por tipología específica type=ROUTER_4G."""
    with patch("app.api.v1.inventory.list_equipment", new_callable=AsyncMock) as mock_list:
        mock_list.return_value = ([], 0)
        res = client.get("/api/v1/inventory/routers?type=ROUTER_4G")
        assert res.status_code == 200


# ==============================================================================
# M06: NOTIFICACIONES OPERATIVAS (API) (2 casos)
# ==============================================================================

def test_tc_m06_02_api_notifications_resend_magic_link_requires_auth(client, mock_db):
    """TC-M06-02: Endpoint de reenvío de Magic Link protegido ante acceso anónimo (HTTP 401)."""
    res = client.post("/api/v1/notifications/send-magic-link", json={"work_order_id": str(uuid.uuid4())})
    assert res.status_code == 401


def test_tc_m06_03_api_notifications_resend_magic_link_not_found(client, auth_coordinator, mock_db):
    """TC-M06-03: Reenvío de Magic Link para orden inexistente responde HTTP 404."""
    res = client.post("/api/v1/notifications/send-magic-link", json={"work_order_id": str(uuid.uuid4())})
    assert res.status_code == 404


# ==============================================================================
# M08: CONTROL DE ACCESO RBAC Y RESILIENCIA CLOUD (API) (2 casos)
# ==============================================================================

def test_tc_m08_01_api_rbac_technician_cannot_access_client_creation(client, auth_technician, mock_db):
    """TC-M08-01: Control RBAC restringe creación de clientes a roles administrativos (TECNICO responde HTTP 403)."""
    client_payload = {
        "business_name": "Intento No Autorizado",
        "contact_email": "test@unauthorized.cl",
        "contact_phone": "+56911112222",
        "address": "Calle 123",
        "comuna": "Santiago",
    }
    res = client.post("/api/v1/clients", json=client_payload)
    assert res.status_code == 403
    assert "insuficientes" in res.json().get("detail", "").lower()


def test_tc_m08_04_api_health_endpoint(client, mock_db):
    """TC-M08-04: Endpoint de verificación de salud del sistema responde HTTP 200 OK."""
    res = client.get("/api/v1/health")
    assert res.status_code == 200
    assert res.json().get("status") == "online"
    assert "Atlas FSM" in res.json().get("service", "")
